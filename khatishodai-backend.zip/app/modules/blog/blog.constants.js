const BlogFilterAbleFileds = [
  "searchTerm",
  "tag",
  "category_id",
  "subCategoryItem_id",
  "brand_id",
];

const BlogSearchableFields = [
  "searchTerm",
  "tag",
  "title",
  "brand_title",
  "category_title",
];

module.exports = {
  BlogFilterAbleFileds,
  BlogSearchableFields,
};
