const BrandFilterAbleFileds = ['searchTerm', 'seller_id', 'category_id', 'subCategory_id', 'subCategoryItem_id' ];

const BrandSearchableFields = ['searchTerm', 'title', 'slug'];


module.exports = {

   BrandFilterAbleFileds,
   BrandSearchableFields

}