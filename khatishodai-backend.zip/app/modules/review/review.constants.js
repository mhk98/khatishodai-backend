const ReviewFilterAbleFileds = [
  "searchTerm",
  "tag",
  "category_id",
  "subCategoryItem_id",
  "brand_id",
];

const ReviewSearchableFields = [
  "searchTerm",
  "tag",
  "title",
  "brand_title",
  "category_title",
];

module.exports = {
  ReviewFilterAbleFileds,
  ReviewSearchableFields,
};
