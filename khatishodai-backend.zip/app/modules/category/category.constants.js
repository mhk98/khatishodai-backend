const CategoryFilterAbleFileds = ['searchTerm', 'tag', 'category_id', 'subCategoryItem_id', 'brand_id' ];

const CategorySearchableFields = ['searchTerm', 'tag', 'title', 'brand_title', 'category_title'];


module.exports = {

  CategoryFilterAbleFileds,
  CategorySearchableFields

}